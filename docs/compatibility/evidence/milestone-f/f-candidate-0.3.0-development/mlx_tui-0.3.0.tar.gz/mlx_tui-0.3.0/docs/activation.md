# Managed activation

The C implementation is opt-in. Existing configurations remain attach mode;
the operator-owned server commands are not used by managed mode.

## Install the TUI

Use the retained wheel bytes for a run, not a source checkout:

```sh
shasum -a 256 mlx_tui-0.2.0-py3-none-any.whl
uv tool install --python 3.13.1 /absolute/path/to/mlx_tui-0.2.0-py3-none-any.whl
```

The current retained wheel SHA-256 is
`6035a385f316363c8aaf6e9ee8fc028aae51b1d1f2ba337fbb5f217f16ba6be1`.
The wheel hash, installed TUI version, Python version, and uv version belong in
the activation record. Wheel installation/network resolution is measured
separately from managed-runtime installation and model downloads.

## Managed runtime inputs

Managed setup uses the packaged `managed-runtime.txt` freeze and
`managed-build-constraints.txt` at the app-owned final path:

```text
$XDG_DATA_HOME/mlx-tui/runtimes/74e7cf9-py3131/
~/.local/share/mlx-tui/runtimes/74e7cf9-py3131/
```

The runtime is MLX-LM 0.32.0 from commit
`74e7cf931e84ef7c2f63e875adf414e20decc1c5`, MLX 0.32.2, and MLX-Metal 0.32.2.
Git is required because MLX-LM is installed from that immutable source commit.
The supported implementation input is Darwin arm64 on macOS 26.6.2 with
Python 3.13.1 and uv 0.12.7. Other OS/version combinations are untested and
remain excluded from C recruitment.

Installation uses the target interpreter explicitly and does not fall back to
an active virtual environment:

```text
uv --no-config venv --allow-existing --python 3.13.1 <runtime-root>
uv --no-config pip sync --python <runtime-root>/bin/python --strict \
  --build-constraints <packaged-build-constraints> <packaged-runtime-freeze>
```

The app records the actual freeze, package metadata, direct URL commit,
resource hashes, and install provenance only after inspection passes. A
cancelled or failed install is incomplete and can be repaired under the same
app-owned lock.

Managed runtime installation does not download models. Model downloads and
their elapsed time are recorded separately by the later setup flow. No live
Milestone B qualification or C recommendation is implied by this artifact.

## First-run setup and ownership

Run `mlx-tui` from any directory. With no config file, the keyboard-first setup
screen offers **Managed runtime** and **Attach server**. Managed mode is the
explicit opt-in path; `--managed` and `--attach` are mutually exclusive CLI
shortcuts. Existing config files remain untouched and keep attach mode unless
their `runtime_mode` is changed or a flag is supplied.

Managed setup installs only under the versioned runtime directory above. It
does not use `start_cmd` or `stop_cmd`, does not adopt a discovered process,
and starts the verified runtime with the fixed C endpoint
`127.0.0.1:18080`. Model downloads remain separate from runtime installation.
Only complete snapshots (tokenizer/config files and all indexed or standalone
Safetensors weights) can be started offline; partial caches produce a repair or
download action. Remote model code is not enabled.

The manager retains the exact child PID/create-time, argv, runtime inspection,
and sanitized launch environment needed for comparison evidence. A green
endpoint from another process is never accepted as managed readiness. Port
conflicts, identity changes, failed loads, and cancellation stay visible as
failure or unknown state; an owned child is stopped and reaped on ordinary
quit, while an attached process is left alone. SIGKILL and power loss cannot
run Python cleanup and are outside this guarantee.

After a failed model switch, **Reload previous model** is an explicit recovery
action. The prior verified path is retained as a recovery option, but a failed
activation is never presented as a successful rollback. Once the runtime and
both pinned snapshots are verified, **Open Compare** enters the existing fixed
`coding-check-v1` workflow; see [the comparison guide](comparison.md).
